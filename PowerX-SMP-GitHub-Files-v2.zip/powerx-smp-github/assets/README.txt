Put your original Untitled.png in this folder. The website CSS is already configured to load it as the top navigation bar background.
