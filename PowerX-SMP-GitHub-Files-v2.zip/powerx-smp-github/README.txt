POWERX SMP WEBSITE

Put these into the root of your GitHub Pages repository:

index.html
shop.html
css/index.css
css/community.css

The old community.html is replaced by shop.html.

Features fixed:
- Removed the accidentally embedded ChatGPT HTML from the homepage.
- Shop now points to shop.html.
- Discord links use https://discord.pwxsmp.net.
- Copy IP buttons copy mc.pwxsmp.net.
- Removed OpenForge template content.
- Fixed the PowerX footer text.
- Kept the existing dark Silex/OpenForge visual style.

The shop products are intentionally placeholders because no real products,
prices, checkout/payment URL, or payment provider were supplied.

## Assets

Place the original `Untitled.png` file in the `assets/` folder. The navbar/top bar is configured to load `../assets/Untitled.png` as its background image.
